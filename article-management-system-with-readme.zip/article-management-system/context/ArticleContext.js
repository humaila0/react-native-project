// context/ArticleContext.js
import { createContext } from 'react';
export const ArticleContext = createContext();
